# Window Controls Overlay API 应用

## 文件结构

```
wco-app/
├── index.html      # 主应用文件
├── manifest.json   # PWA 清单
├── sw.js          # Service Worker
├── icon-192.svg   # 小图标
├── icon-512.svg   # 大图标
└── README.md      # 说明文件
```

## 运行方式

由于 Window Controls Overlay API 需要 HTTPS 环境和 PWA 安装，请按以下步骤运行：

### 方法 1: 使用本地 HTTPS 服务器

```bash
# 安装 serve (如果没有)
npm install -g serve

# 使用 HTTPS 运行
serve -s . --ssl-cert cert.pem --ssl-key key.pem
```

### 方法 2: 使用 Python HTTPS 服务器

```bash
# 生成自签名证书
openssl req -newkey rsa:2048 -new -nodes -x509 -days 3650 -keyout key.pem -out cert.pem

# 运行服务器
python3 -m http.server 8080
```

### 方法 3: 部署到支持 HTTPS 的服务器

将文件上传到任何支持 HTTPS 的 Web 服务器。

## 使用步骤

1. 在 HTTPS 环境中打开应用
2. 安装 PWA（浏览器会提示安装）
3. 以已安装的 PWA 模式运行应用
4. 享受自定义标题栏功能

## API 功能

- `navigator.windowControlsOverlay.visible` - 检查覆盖层可见性
- `navigator.windowControlsOverlay.getBoundingClientRect()` - 获取几何信息
- `geometrychange` 事件 - 监听几何变化

## CSS 环境变量

- `env(titlebar-area-height)` - 标题栏高度
- `env(titlebar-area-width)` - 标题栏宽度
- `env(titlebar-area-x)` - 标题栏 X 坐标
- `env(titlebar-area-y)` - 标题栏 Y 坐标

## 浏览器支持

- Chrome 105+
- Edge 105+
- Opera 91+
